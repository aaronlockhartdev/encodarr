import{a as t}from"../chunks/entry.DoI9sZ07.js";export{t as start};
